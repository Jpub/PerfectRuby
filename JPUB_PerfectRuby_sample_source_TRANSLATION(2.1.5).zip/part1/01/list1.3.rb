p 1.to_s # "1" 을 출력
p true.to_s # "true" 를 출력
