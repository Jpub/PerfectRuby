﻿# encoding: utf-8
puts '안녕하세요'
