# coding: utf-8

class BaseClass
  def hello
    :hello
  end
end

base_object = BaseClass.new
base_object.hello #=> :hello
