■tasks 디렉터리
14-2-4부터 14-2-12까지의 각종 task나 후크를 사용한 샘플이 들어있다.

■deploy_sample 디렉터리
14-2-13에서 소개한 multi stage 샘플이 들어있다.
