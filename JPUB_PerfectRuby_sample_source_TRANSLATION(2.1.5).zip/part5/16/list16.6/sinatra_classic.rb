require 'sinatra'

get '/' do
  'Classic Style Sinatra!'
end
