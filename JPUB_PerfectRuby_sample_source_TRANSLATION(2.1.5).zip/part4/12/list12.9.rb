# ==RubyKaigiStaff Class
#
# http://rubykaigi.org
# https://rubykaigi.org
#
# 아래는 <img>로 변경된다
# http://rubykaigi.org/2011/photos/200702.png
class RubyKaigiStaff
  def takkanm
    '@takkanm'
  end
end
