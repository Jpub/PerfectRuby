﻿p 'hello'.class # String 을 출력
p String.ancestors # [String, Comparable, Object, Kernel, BasicObject] 을 출력
p 10.class # Fixnum 을 출력
p Fixnum.ancestors # [Fixnum, Integer, Numeric, Comparable, Object, Kernel, BasicObject] 을 출력
p true.class # TrueClass를 출력
p TrueClass.ancestors # [TrueClass, Object, Kernel, BasicObject] 를 출력
p nil.class # NilClass를 출력
p NilClass.ancestors # [NilClass, Object, Kernel, BasicObject]를 출력
