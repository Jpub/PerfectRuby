﻿class Sample
  def say
    puts 'Hello, world!'
  end
end

sample = Sample.new
sample.say # Hello, world! 출력
