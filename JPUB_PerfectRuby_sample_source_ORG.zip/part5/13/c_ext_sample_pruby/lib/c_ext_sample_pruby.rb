require "c_ext_sample_pruby/version"
require "c_ext_sample_pruby/c_ext_sample_pruby"

module CExtSamplePruby
  # Your code goes here...
end
