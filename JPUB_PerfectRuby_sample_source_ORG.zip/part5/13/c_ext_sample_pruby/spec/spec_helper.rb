$LOAD_PATH.unshift File.expand_path('../../lib', __FILE__)
require 'c_ext_sample_pruby'
