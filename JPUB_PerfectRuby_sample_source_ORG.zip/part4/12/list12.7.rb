# ==Rubyist Module
module Rubyist
  # ==Developer Class
  class Developer # :nodoc: 
    def ryopeko
    '@ryopeko'
    end
  end

  # ==RubyKaigiStaff Class
  class RubyKaigiStaff
    def takkanm
      '@takkanm'
    end
  end
end

# ==Manager Module
module Manager # :nodoc: all
  # ==Leader Class
  class Leader
  end
end
