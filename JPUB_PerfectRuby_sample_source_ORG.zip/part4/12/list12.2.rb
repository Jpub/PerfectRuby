# 반환 값을 표시한다
IRB.conf[:ECHO] = true
