#open-uri와 pp를 시작시에 require한다
IRB.conf[:LOAD_MODULES] = 'open-uri', 'pp'
