class Poke
  private
  # == 힘내자!
  def touch # :doc:
    p '파이팅!'
  end
end
