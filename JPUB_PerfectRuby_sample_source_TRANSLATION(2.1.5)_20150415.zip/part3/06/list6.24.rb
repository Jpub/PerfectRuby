# coding: utf-8

require './refine_module'

'Tom'.hello
