# coding: utf-8

class String
  def hello
    puts "#{self} hello"
  end
end

'Bob'.hello #=> 'Bob hello'
