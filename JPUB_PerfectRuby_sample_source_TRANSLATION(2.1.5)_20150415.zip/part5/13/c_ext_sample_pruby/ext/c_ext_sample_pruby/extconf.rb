require 'mkmf'

create_makefile('c_ext_sample_pruby/c_ext_sample_pruby')
