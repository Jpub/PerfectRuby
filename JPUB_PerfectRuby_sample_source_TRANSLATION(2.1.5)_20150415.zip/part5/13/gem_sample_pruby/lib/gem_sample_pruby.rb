require "gem_sample_pruby/version"

module GemSamplePruby
  def self.hello_pruby
    p "hello pruby!!"
  end
end
