﻿이 샘플을 가지고 문서를 생성할 때는
yardoc 명령에 --private 옵션을 붙여 주세요

문서 생성 예
% yardoc --private yard_tags.rb

yardoc 실행 시에는, 대상 파일 경로에 한글이 포함되지 않도록 주의해주세요
