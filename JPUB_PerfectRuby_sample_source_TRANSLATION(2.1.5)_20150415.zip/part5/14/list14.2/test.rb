# test.rb
require 'bundler'

Bundler.require
self.tapp
