﻿puts 'Hello, world!' # Hello, world! 출력
