﻿puts '안녕하세요'
